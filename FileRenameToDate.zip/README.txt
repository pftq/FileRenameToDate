FileRenameToDate by pftq
Jan.2023
www.pftq.com

This script renames files to date created with optional time shifting for timezones and out-of-sync devices.  The last bit is what's most useful about this script, as often I have to sync photos across cameras or deal with devices that briefly stopped keeping time.

The script is short and sweet.  The source code is included for anyone that might need to tweak it for their use.
